using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomObjectCreator : MonoBehaviour
{
    public GameObject prefab; // Ҫʵ������Ԥ����
    private Vector3 spawnArea = new Vector3(10, 10, 10); // ������������Χ
    private GameObject lastCreatedObject;
    private float timeSinceLastSpawn = 0f;

    void Start()
    {
        // ����ʱ�������5������
        for (int i = 0; i < 5; i++)
        {
            SpawnRandomObject();
        }
    }

    void Update()
    {
        // ÿ��2�봴��һ���µ�����
        if (timeSinceLastSpawn >= 2f)
        {
            SpawnRandomObject();
            timeSinceLastSpawn = 0f;
        }
        else
        {
            timeSinceLastSpawn += Time.deltaTime;
        }
    }

    void SpawnRandomObject()
    {
        // �������λ��
        Vector3 randomPosition = new Vector3(
            Random.Range(-spawnArea.x / 2, spawnArea.x / 2),
            Random.Range(-spawnArea.y / 2, spawnArea.y / 2),
            Random.Range(-spawnArea.z / 2, spawnArea.z / 2)
        );

        // ʵ����Ԥ����
        lastCreatedObject = Instantiate(prefab, randomPosition, Quaternion.identity);

        // �����������Ĵ�С
        float randomScale = Random.Range(0.5f, 2f);
        lastCreatedObject.transform.localScale = new Vector3(randomScale, randomScale, randomScale);
    }

    void OnGUI()
    {
        if (lastCreatedObject != null)
        {
            string objectInfo = $"Name: {lastCreatedObject.name}\n" +
                                $"Position: {lastCreatedObject.transform.position}\n" +
                                $"Size: {lastCreatedObject.transform.localScale}";

            GUI.Label(new Rect(Screen.width - 200, 10, 200, 100), objectInfo);
        }
    }
}
