using UnityEditor;
using UnityEngine;

[InitializeOnLoad]
public class GlobalCoordinateSystem
{
    static GlobalCoordinateSystem()
    {
        SceneView.duringSceneGui += OnSceneGUI;
    }

    static bool isVisible = true;
    private static float axisLength = 10f;
    private static float cubeSize = 0.2f;

    static void OnSceneGUI(SceneView sceneView)
    {
        if (!isVisible) return;

        Handles.color = Color.red;
        DrawAxis(Vector3.right, Color.red);

        Handles.color = Color.green;
        DrawAxis(Vector3.up, Color.green);

        Handles.color = Color.blue;
        DrawAxis(Vector3.forward, Color.blue);
    }

    static void DrawAxis(Vector3 direction, Color color)
    {
        Vector3 start = Vector3.zero;
        Vector3 end = direction * axisLength;

        Handles.DrawLine(start, end);

        Matrix4x4 originalMatrix = Handles.matrix;
        Handles.matrix = Matrix4x4.TRS(end, Quaternion.identity, Vector3.one * cubeSize);
        Handles.color = color;
        Handles.CubeHandleCap(0, Vector3.zero, Quaternion.identity, 1f, EventType.Repaint);
        Handles.matrix = originalMatrix;
    }

    [MenuItem("Custom Tools/Toggle Global Coordinate System")]
    static void ToggleVisibility()
    {
        isVisible = !isVisible;
        SceneView.RepaintAll();
    }

    public static void SetAxisLength(float length)
    {
        axisLength = length;
    }

    public static void SetCubeSize(float size)
    {
        cubeSize = size;
    }
}

using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(Transform))]
public class CustomTransformInspector : Editor
{
    private float axisLength = 10f;
    private float cubeSize = 0.2f;

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        if (Selection.activeGameObject != null)
        {
            GUILayout.Space(10);
            GUILayout.Label("Global Coordinate System Settings", EditorStyles.boldLabel);

            axisLength = EditorGUILayout.FloatField("Axis Length", axisLength);
            cubeSize = EditorGUILayout.FloatField("Cube Size", cubeSize);

            if (GUI.changed)
            {
                // ����ȫ������ϵ������
                GlobalCoordinateSystem.SetAxisLength(axisLength);
                GlobalCoordinateSystem.SetCubeSize(cubeSize);
                SceneView.RepaintAll();
            }
        }
    }
}